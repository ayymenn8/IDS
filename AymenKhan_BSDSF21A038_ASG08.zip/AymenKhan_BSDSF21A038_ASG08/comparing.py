import time
import random
from algorithms.sorting.sorting import bubble_sort, merge_sort
from algorithms.searching.searching import linear_search, binary_search

def generate_array(size):
    return [random.randint(1, 1000000) for _ in range(size)]

def generate_sorted_array(size):
    return sorted(generate_array(size))

def time_sorting_algorithm(sorting_algorithm, arr):
    start_time = time.time()
    sorting_algorithm(arr.copy())
    end_time = time.time()
    return end_time - start_time

def time_searching_algorithm(searching_algorithm, arr, key):
    start_time = time.time()
    searching_algorithm(arr, key)
    end_time = time.time()
    return end_time - start_time

array_sizes = [1000, 5000, 10000, 50000, 100000]  # Varying sizes of arrays
key = random.randint(1, 1000000)  # Random key for searching

# Performance comparison for sorting algorithms
print("Sorting Algorithms Performance Comparison:")
for size in array_sizes:
    unsorted_array = generate_array(size)
    sorted_array = generate_sorted_array(size)
    bubble_sort_time = time_sorting_algorithm(bubble_sort, unsorted_array)
    merge_sort_time = time_sorting_algorithm(merge_sort, unsorted_array)
    print(f"Array size: {size}, Bubble Sort Time: {bubble_sort_time:.6f} seconds, Merge Sort Time: {merge_sort_time:.6f} seconds")

# Performance comparison for searching algorithms
print("\nSearching Algorithms Performance Comparison:")
for size in array_sizes:
    unsorted_array = generate_array(size)
    sorted_array = generate_sorted_array(size)
    linear_search_time_unsorted = time_searching_algorithm(linear_search, unsorted_array, key)
    binary_search_time_unsorted = time_searching_algorithm(binary_search, unsorted_array, key)
    linear_search_time_sorted = time_searching_algorithm(linear_search, sorted_array, key)
    binary_search_time_sorted = time_searching_algorithm(binary_search, sorted_array, key)
    print(f"Array size: {size}, Linear Search Time (Unsorted): {linear_search_time_unsorted:.6f} seconds, Binary Search Time (Unsorted): {binary_search_time_unsorted:.6f} seconds, Linear Search Time (Sorted): {linear_search_time_sorted:.6f} seconds, Binary Search Time (Sorted): {binary_search_time_sorted:.6f} seconds")
